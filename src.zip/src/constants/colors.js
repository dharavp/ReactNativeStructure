const colors = {
    primary: 'yellow',
    headerText: 'red',
    button: '#036675'
}

export default colors;