export default titles = {
    HEADING: 'Heading',
    title2: 'we are here again'
}