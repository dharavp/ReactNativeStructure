import Home from './Home';
import Splash from './Splash';

export {
    Home,
    Splash
}