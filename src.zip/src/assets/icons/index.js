// export const IC_LOGIN_LOGO = require('./login_logo.jpg')

const icons = {
    IC_LOGIN_LOGO: require('./login_logo.jpg')
}

export default icons;