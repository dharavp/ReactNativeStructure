export default keys = {
    async: {
        commonConfiguration: 'commonConfiguration',
        currentUserData: 'currentUser',
    }
}