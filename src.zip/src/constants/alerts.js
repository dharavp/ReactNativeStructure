const alerts = {
    logout: 'Are you sure you want to logout?',
    alert1: 'this is alert1 for testing'
}
export default alerts;